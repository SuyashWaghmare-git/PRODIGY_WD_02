import { useState, useEffect, useRef } from 'react';

function App() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = window.setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 10);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const formatTime = (centiseconds: number) => {
    const hours = Math.floor(centiseconds / 360000);
    const minutes = Math.floor((centiseconds % 360000) / 6000);
    const seconds = Math.floor((centiseconds % 6000) / 100);
    const cs = centiseconds % 100;

    return {
      hours: hours.toString().padStart(2, '0'),
      minutes: minutes.toString().padStart(2, '0'),
      seconds: seconds.toString().padStart(2, '0'),
      centiseconds: cs.toString().padStart(3, '0'),
    };
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTime(0);
  };

  const timeSegments = formatTime(time);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-8">
      <div className="flex flex-col lg:flex-row items-center gap-16 max-w-6xl">
        <div className="relative">
          <div className="absolute -inset-4 bg-gray-300 rounded-3xl opacity-50 blur-sm"></div>

          <div className="relative bg-black rounded-3xl p-12 shadow-2xl">
            <div className="bg-blue-600 rounded-2xl px-8 py-6 mb-8">
              <div className="flex items-center justify-center gap-3 text-white font-bold">
                <span className="text-5xl">{timeSegments.hours}</span>
                <span className="text-4xl">:</span>
                <span className="text-5xl">{timeSegments.minutes}</span>
                <span className="text-4xl">:</span>
                <span className="text-5xl">{timeSegments.seconds}</span>
                <span className="text-4xl">:</span>
                <span className="text-5xl">{timeSegments.centiseconds}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-4">
              <button
                onClick={handleStart}
                disabled={isRunning}
                className="bg-white hover:bg-gray-100 text-black font-bold px-8 py-4 rounded-lg text-xl transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
              >
                Start
              </button>
              <button
                onClick={handlePause}
                disabled={!isRunning}
                className="bg-white hover:bg-gray-100 text-black font-bold px-8 py-4 rounded-lg text-xl transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
              >
                Pause
              </button>
              <button
                onClick={handleReset}
                className="bg-white hover:bg-gray-100 text-black font-bold px-8 py-4 rounded-lg text-xl transition-all duration-200 active:scale-95"
              >
                Reset
              </button>
            </div>
          </div>
        </div>

        <div className="text-right">
          <h1 className="text-7xl font-black text-black mb-4 tracking-tight">
            STOPWATCH
          </h1>
          <div className="bg-blue-600 inline-block px-8 py-3">
            <p className="text-4xl font-black text-white tracking-wide">
              WITH JAVASCRIPT
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
